// In App.js in a new project
// @refresh reset
import React, { useEffect } from 'react';
import { SafeAreaView, Animated, Dimensions, Image, Platform, StyleSheet, Text, TouchableOpacity, View } from 'react-native';
import 'react-native-gesture-handler';
import { NavigationContainer } from '@react-navigation/native';
import { createBottomTabNavigator } from '@react-navigation/bottom-tabs';
import { createStackNavigator } from '@react-navigation/stack';
import firebase from './apps/src/components/FireScript';

import plus from './assets/plus.png'

// Font Awesome Icons...
import { FontAwesome5 } from '@expo/vector-icons'

//const Stack = createStackNavigator();
import { useRef } from 'react';
import { IndexSign } from './apps/src/publics/screens/signs/index.sign';
import { LoginSignScreen } from './apps/src/publics/screens/signs/LoginSignScreen';
import { RegisterSignScreen } from './apps/src/publics/screens/signs/RegisterSignScreen';
import { MainNavigation } from './apps/src/publics/screens/mains/MainNavigation';
import { OnboardingScreen } from './apps/src/publics/screens/OnboardingScreen';
import ProductDetailsScreen from './apps/src/publics/screens/products/ProductDetailsScreen';
import VerificationScreen from './apps/src/publics/screens/mains/VerificationScreen';
import CheckoutPayment from './apps/src/publics/screens/mains/CheckoutPayment';
import ListAllProduct from './apps/src/publics/screens/user-dashboard/OwnProduct/ListAllProduct';
import UpdateProduct from './apps/src/publics/screens/user-dashboard/OwnProduct/UpdateProduct';
import EditOwnProfil from './apps/src/publics/screens/user-dashboard/EditOwnProfil';
import AboutUsScreen from './apps/src/publics/screens/mains/AboutUsScreen';
import VerifyIfIsVerified from './apps/src/publics/screens/mains/VerifyIfIsVerified';
import { ProfilMainScreen } from './apps/src/publics/screens/mains/ProfilMainScreen';
import InfoBankAccount from './apps/src/publics/screens/user-dashboard/InfoBankAccount';
import { CreateOwnProductBikees } from './apps/src/publics/screens/products/CreateOwnProductBikees';
import ChatWithSpecificUser from './apps/src/publics/screens/mains/components/ChatWithSpecificUser';
import CGUBikees from './apps/src/publics/screens/user-dashboard/CGUBikees';
import LocationHistory from './apps/src/publics/screens/user-dashboard/LocationHistory';
import ReservationScreen from './apps/src/publics/screens/mains/ReservationScreen';
import WalletsMainScreen from './apps/src/publics/screens/mains/WalletsMainScreen';
import RequestOnProduct from './apps/src/publics/screens/products/RequestOnProduct';
import ForgetPassword from './apps/src/publics/screens/signs/ForgetPassword';
import OrdersDetailsDisplay from './apps/src/publics/screens/user-dashboard/OrdersDetailsDisplay';
import SplashScreen from './apps/SplashScreen';
import { MapsTest } from './apps/MapsTest';

const Tab = createBottomTabNavigator();
const Stack = createStackNavigator();

// const isAuthLogged = () => {
//   // Listen for authentication state to change.
//   firebase.auth().onAuthStateChanged(user => {
//     if (user != null) {
//       console.log('We are authenticated now!');
//     }

//     // Do other things
//   });
// }

export default function App() {

  return (
    <NavigationContainer>
     
        <Stack.Navigator backgroundColor={'#FFF'} screenOptions={{headerShown: false}}>
          {
          // <Stack.Screen name="Onboarding" component={OnboardingScreen}/>
          // <Stack.Screen name="Login" component={LoginSignScreen}/>
          // <Stack.Screen name="Register" component={RegisterSignScreen}/>
          // <Stack.Screen name="Login" component={LoginSignScreen}/>
          // <Stack.Screen name="SplashScreenBikees" component={SplashScreen}/>
          }
          <Stack.Screen name="Onboarding" component={OnboardingScreen}/>
          <Stack.Screen name="Login" component={LoginSignScreen}/>
          <Stack.Screen name="Register" component={RegisterSignScreen}/>
          <Stack.Screen name="ForgetPassW" component={ForgetPassword}/>
          <Stack.Screen name="MainNavigation" component={MainNavigation}/>
          <Stack.Screen name="ProductDetail" component={ProductDetailsScreen}/>
          <Stack.Screen name="Verification" component={VerificationScreen}/>
          <Stack.Screen name="BookingBikees" component={ReservationScreen}/>
          <Stack.Screen name="CreateProduct" component={CreateOwnProductBikees}/>
          <Stack.Screen name="CheckoutPayments" component={CheckoutPayment}/>
          <Stack.Screen name="ListBikees" component={ListAllProduct}/>
          <Stack.Screen name="EditOwnBikees" component={UpdateProduct}/>
          <Stack.Screen name="EditsProfil" component={EditOwnProfil}/>
          <Stack.Screen name="UserProfil" component={ProfilMainScreen}/>
          <Stack.Screen name="AboutUsBikees" component={AboutUsScreen}/>
          <Stack.Screen name="VerificationIIF" component={VerifyIfIsVerified}/>
          <Stack.Screen name="BankAccount" component={InfoBankAccount}/>
          <Stack.Screen name="WalletsInfos" component={WalletsMainScreen}/>
          <Stack.Screen name="ChatRoomUser" component={ChatWithSpecificUser}/>
          <Stack.Screen name="CGUBikees" component={CGUBikees}/>
          <Stack.Screen name="RequestBikees" component={RequestOnProduct}/>
          <Stack.Screen name="HistoryLocation" component={LocationHistory}/>
          <Stack.Screen name="OrderDetails" component={OrdersDetailsDisplay}/>
          <Stack.Screen name="MapsTest" component={MapsTest}/>
        </Stack.Navigator>
    </NavigationContainer>
    
  )
  
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#fff',
    alignItems: 'center',
    justifyContent: 'center',
  },
});

