# BIKEES APPS, mise en place de verification
# bikeesappnonfinal
