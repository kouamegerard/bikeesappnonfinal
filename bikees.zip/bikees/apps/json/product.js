const product = [

    {
        id: '1', 
        name: 'Bikees VTP', 
        priceDay: '23.7',
        priceHour: '10.2',
        image: require('../src/publics/images/ridebikees.png'),
        description: 'Phasellus nec semper turpis. Ut in fringilla nisl, sit amet aliquet urna. Donec sollicitudin libero sapien, ut accumsan justo venenatis et. Proin iaculis ac dolor eget malesuada. Cras commodo, diam id semper sodales, tortor leo suscipit leo, vitae dignissim velit turpis et diam. Proin tincidunt.',
        status: 'Disponible',
    },
    {
        id: '2', 
        name: 'Bikees VTT', 
        priceDay: '29.02',
        priceHour: '10.9',
        image: require('../src/publics/images/ridebikees.png'),
        description: 'Phasellus nec semper turpis. Ut in fringilla nisl, sit amet aliquet urna. Donec sollicitudin libero sapien, ut accumsan justo venenatis et. Proin iaculis ac dolor eget malesuada. Cras commodo, diam id semper sodales, tortor leo suscipit leo, vitae dignissim velit turpis et diam. Proin tincidunt.',
        status: 'Loué',
    },
    {
        id: '3', 
        name: 'Bikees Tout Terrain', 
        priceDay: '17',
        priceHour: '7',
        image: require('../src/publics/images/ridebikees.png'),
        description: 'Phasellus nec semper turpis. Ut in fringilla nisl, sit amet aliquet urna. Donec sollicitudin libero sapien, ut accumsan justo venenatis et. Proin iaculis ac dolor eget malesuada. Cras commodo, diam id semper sodales, tortor leo suscipit leo, vitae dignissim velit turpis et diam. Proin tincidunt.',
        status: 'Loué',
    },
    {
        id: '4', 
        name: 'Bikees VTP', 
        priceDay: '21',
        priceHour: '9',
        image: require('../src/publics/images/ridebikees.png'),
        description: 'Phasellus nec semper turpis. Ut in fringilla nisl, sit amet aliquet urna. Donec sollicitudin libero sapien, ut accumsan justo venenatis et. Proin iaculis ac dolor eget malesuada. Cras commodo, diam id semper sodales, tortor leo suscipit leo, vitae dignissim velit turpis et diam. Proin tincidunt.',
        status: 'Disponible',
    },
    {
        id: '5', 
        name: 'Bikees VTP', 
        priceDay: '43',
        priceHour: '22',
        image: require('../src/publics/images/ridebikees.png'),
        description: 'Phasellus nec semper turpis. Ut in fringilla nisl, sit amet aliquet urna. Donec sollicitudin libero sapien, ut accumsan justo venenatis et. Proin iaculis ac dolor eget malesuada. Cras commodo, diam id semper sodales, tortor leo suscipit leo, vitae dignissim velit turpis et diam. Proin tincidunt.',
        status: 'Loué',
    },
    {
        id: '6', 
        name: 'Bikees VTP', 
        priceDay: '71',
        priceHour: '12',
        image: require('../src/publics/images/ridebikees.png'),
        description: 'Phasellus nec semper turpis. Ut in fringilla nisl, sit amet aliquet urna. Donec sollicitudin libero sapien, ut accumsan justo venenatis et. Proin iaculis ac dolor eget malesuada. Cras commodo, diam id semper sodales, tortor leo suscipit leo, vitae dignissim velit turpis et diam. Proin tincidunt.',
        status: 'Loué',
    },
    
];
  
  export default product;