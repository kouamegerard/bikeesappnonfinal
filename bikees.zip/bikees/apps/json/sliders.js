export default [
    {
        id: '1',
        title: 'Déplacez-vous en Bikees',
        description: 'Trouvez un vélo à louer dans toute la France !',
        image: require('../src/publics/images/bikees-onboard.png'),
    },
    {
        id: '2',
        title: 'Gagnez de l\'argent',
        description: 'Et de la place en mettant en location votre vélo.',
        image: require('../src/publics/images/gagnez_de_argent.png'),
    },
]