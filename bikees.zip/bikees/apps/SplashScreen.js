import React, { useCallback, useEffect, useRef, useState } from 'react'
import { StyleSheet, Text, View, SafeAreaView, 
    Animated, Dimensions, Image 
} from 'react-native'
import * as SplashScreens from 'expo-splash-screen';

const logo = require('./src/publics/images/logo-bikees-green.png')

const SplashScreen = ({navigation}) => {

    const animatedIt = useRef(new Animated.Value(0)).current;
    const fadeAnimatedIt = useRef(new Animated.Value(0)).current;
    const [appIsReady, setAppIsReady] = useState(false);

    useEffect(() => {
      async function prepare() {
        try {
          // Keep the splash screen visible while we fetch resources
          await SplashScreens.preventAutoHideAsync();
          // Pre-load fonts, make any API calls you need to do here
          // Artificially delay for two seconds to simulate a slow loading
          // experience. Please remove this if you copy and paste the code!
          await new Promise(resolve => setTimeout(resolve, 2000));
        } catch (e) {
          console.warn(e);
        } finally {
          // Tell the application to render
          setAppIsReady(true);
        }
      }
  
      prepare();
    }, []);

    const onLayoutRootView = useCallback(async () => {
        if (appIsReady) {
          // This tells the splash screen to hide immediately! If we call this after
          // `setAppIsReady`, then we may see a blank screen while the app is
          // loading its initial state and rendering its first pixels. So instead,
          // we hide the splash screen once we know the root view has already
          // performed layout.
          await SplashScreens.hideAsync();
        }

        //console.log(appIsReady);
      }, [appIsReady]);
    
    if (!appIsReady) {
        console.log(appIsReady);
        return null;
    }

    return (
        <SafeAreaView 
            style={styles.container}
            onLayout={onLayoutRootView}
        >
            <View style={styles.contain}>
                <Image source={logo} style={styles.imageLogo}/>
            </View>
            <Text style={styles.corporate}>Fam Digital</Text>
        </SafeAreaView>
    )
}

export default SplashScreen

const styles = StyleSheet.create({
    container: {
        flex: 1,
        justifyContent: 'center',
        alignItems: 'center',
        backgroundColor: '#FFF',
    },
    contain: {
        width: '90%',
        alignItems: 'center',
    },
    imageLogo: {
        width: '50%',
        resizeMode: 'contain'
    },
    corporate: {
        position: 'absolute',
        bottom: 32,
        fontWeight: '400'
    }
})
