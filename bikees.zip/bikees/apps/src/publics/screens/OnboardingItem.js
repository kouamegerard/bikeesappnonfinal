import React from 'react'
import { StyleSheet, Text, View, useWindowDimensions, Image } from 'react-native'

export const OnboardingItem = ({ item }) => {
    const { width } = useWindowDimensions();
    return (
        <View style={[styles.container, { width }]}>
            <Image source={ item.image } style={[styles.imageBox, {width, resizeMode:'center'}]} />
            <View style={styles.textBox}>
                <Text style={styles.textTitle}>{item.title}</Text>
                <Text style={styles.textDescription}>{item.description}</Text>
            </View>
        </View>
    )
}

const styles = StyleSheet.create({
    container: {
        flex: 1,
        alignItems: 'center',
        justifyContent: 'center',
    },
    imageBox: {
        flex: .7,
        justifyContent: 'center',
    },
    textBox: {
        flex: .3,
    },
    textTitle: {
        fontWeight: '800',
        fontSize: 28,
        marginBottom: 16,
        color: '#96bf0f',
        textAlign: 'center',
    },
    textDescription: {
        fontWeight: '300',
        color: '#96bf0f',
        textAlign: 'center',
        paddingHorizontal: 64,
    }
})
