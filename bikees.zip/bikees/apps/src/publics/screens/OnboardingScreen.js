import React, { useState, useRef } from 'react'
import { StyleSheet, Text, View, SafeAreaView, Animated, FlatList } from 'react-native'

// Own JS files

// JSON Slide
import sliders from '../../../json/sliders';
import { OnboardingItem } from './OnboardingItem';
import { PaginationOnboarding } from '../../navigations/PaginationOnboarding';

export const OnboardingScreen = ({ navigation }) => {
    const [currentIndex, setCurrentIndex] = useState(0);
    const sliderRef = useRef(null);
    const scrollX = useRef(new Animated.Value(0)).current;

    const viewableItemsChanged = useRef(({ viewableItems }) => {
        setCurrentIndex(viewableItems[0].index);
    }).current;

    const viewConfig = useRef({viewAreaCoveragePercentThreshold: 50}).current

    return (
        <SafeAreaView style={styles.container}>
            <View style={styles.onboardContainer}>
                <View style={{flex: 3}}>
                    <FlatList data={sliders} 
                        renderItem={({ item })=> <OnboardingItem item={item} />} 
                        horizontal
                        showsHorizontalScrollIndicator={false}
                        pagingEnabled
                        bounces={false}
                        scrollIndicatorInsets={false}
                        keyExtractor={(item) => item.id}
                        onScroll={Animated.event([{ nativeEvent: { contentOffset: { x: scrollX } }}], 
                            {useNativeDriver: false,}
                        )}
                        scrollEventThrottle={32}
                        onViewableItemsChanged={viewableItemsChanged}
                        viewabilityConfig={viewConfig}
                        ref={sliderRef}
                    />

                </View>
                
                <PaginationOnboarding pagination={sliders} scrollX={scrollX} />
                
                <View style={styles.skipView}>
                    <Text 
                        style={styles.skipText}
                        onPress={() => navigation.navigate('Login')}
                    >Skip</Text>
                </View>

            </View>
        </SafeAreaView>
    )
}

const styles = StyleSheet.create({
    container: {
        flex: 1,
        alignItems: 'center',
        justifyContent: 'center',
        backgroundColor: '#FFF',
        //marginTop: Platform.OS === "android" ? StatusBar.currentHeight : 42,
    },
    onboardContainer: {
        flex: 1,
    },
    imageOnboard: {
        width: '100%',
        height: '80%',
        resizeMode: 'cover',
    },
    skipView: {
        flex: .1,
        alignItems: 'flex-end',
        justifyContent: 'center',
        marginHorizontal: 32,
    },
    skipText: {
        color: '#f00',
    }

})
