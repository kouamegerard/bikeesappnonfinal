import { useState } from "react";

export const [location, setLocation] = useState(null);
export const [errorMsg, setErrorMsg] = useState(null);

export const [pin, setPinState] = useState({
    latitude: '',
    longitude: ''
})


useEffect(() => {
    (async () => {
      let { status } = await Location.requestForegroundPermissionsAsync();
      if (status !== 'granted') {
        setErrorMsg('Bikees a besoin de votre permission à la localisation');
        return;
      }

      let location = await Location.getCurrentPositionAsync({});
      setLocation(location);
    })();
}, []);

let textLoc = 'Waiting..';
if (errorMsg) {
    textLoc = errorMsg;
} else if (location) {
    textLoc = JSON.stringify(location.coords.latitude + ':' + location.coords.longitude);
    setPinState(location.coords.latitude, location.coords.longitude)
}