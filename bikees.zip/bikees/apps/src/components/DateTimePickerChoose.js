import React, { useEffect, useState } from 'react';
import { StyleSheet, View, Button, Platform, Text } from 'react-native';
import DateTimePicker from '@react-native-community/datetimepicker';
import DatePicker from 'react-native-date-picker'
import DateTimePickerModal from "react-native-modal-datetime-picker";

export const DateTimePickerChoose = ({priceD, priceH}) => {

  const [isDatePickerVisible, setDatePickerVisibility] = useState(false);
  const [datePicks, setDatePicks] = useState('')
  const [isDatePickerVisiblef, setDatePickerVisibilityf] = useState(false);
  const [datePickf, setDatePickf] = useState('')
  const [totals, setTotal] = useState()

  const [years, setYears] = useState()
  const [months, setMonths] = useState()
  const [days, setDays] = useState()
  const [hours, setHours] = useState()
  const [minutes, setMinutes] = useState()
  const [seconds, setSeconds] = useState()

  const [yearf, setYearf] = useState()
  const [monthf, setMonthf] = useState()
  const [dayf, setDayf] = useState()
  const [hourf, setHourf] = useState()
  const [minutef, setMinutef] = useState()
  const [secondf, setSecondf] = useState()

  const showDatePicker = () => {
    setDatePickerVisibility(true);
  };

  const hideDatePicker = () => {
    setDatePickerVisibility(false);
  };

  const handleConfirm = (date) => {
    setDatePicks(date.getFullYear() +'-'+(date.getMonth() + 1)+'-'+date.getDate() + ' ' + date.getHours()+':'+date.getMinutes())
    setYears(date.getFullYear())
    setMonths(date.getMonth() + 1)
    setDays(date.getDate())
    setHours(date.getHours())
    setMinutes(date.getMinutes())
    setSeconds(date.getSeconds())
    hideDatePicker();
  };

  /**
   * Date de fin
   */

  const showDatePickerf = () => {
    setDatePickerVisibilityf(true);
  };

  const hideDatePickerf = () => {
    setDatePickerVisibilityf(false);
  };

  const handleConfirmf = (date) => {
    setDatePickf(date.getFullYear() +'-'+(date.getMonth() + 1)+'-'+date.getDate()+ ' ' +date.getHours()+':'+date.getMinutes())
    setYearf(date.getFullYear())
    setMonthf(date.getMonth() + 1)
    setDayf(date.getDate())
    setHourf(date.getHours())
    setMinutef(date.getMinutes())
    setSecondf(date.getSeconds())
    hideDatePickerf();
  };
  
  useEffect(() => {

    const year = ((yearf-years) / 366) * priceD
    const month = ((monthf-months) / 30) * priceD
    const day = (dayf-days) * priceD
    const hour = (hourf-hours) * priceH
    const min = ((minutef-minutes) / 60) * priceH
    const sec = ((secondf-seconds) / 3600) * priceH
    
    const total = year+ month + day + hour + min + sec
    console.log(total)
    setTotal(total.toFixed(2))

  }, [])

  return (
    <View style={styles.container}>
      <Button title="Date et Heure de debut" onPress={showDatePicker} />
      <Text>{datePicks} </Text>
      <DateTimePickerModal
        isVisible={isDatePickerVisible}
        mode="datetime"
        is24Hour={true}
        onConfirm={handleConfirm}
        onCancel={hideDatePicker}
      />
      <View>
        <Button title="Date et heure de Fin" onPress={showDatePickerf} />
        <Text>{datePickf}</Text>
        <DateTimePickerModal
          isVisible={isDatePickerVisiblef}
          mode="datetime"
          onConfirm={handleConfirmf}
          onCancel={hideDatePickerf}
        />
      </View>
      <Text>{totals < 0 ? 'Total: ' + (-totals) : 'Total: ' + totals}</Text>
    </View>
  );

};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#fff',
    alignItems: 'center',
    justifyContent: 'center',
  },
});