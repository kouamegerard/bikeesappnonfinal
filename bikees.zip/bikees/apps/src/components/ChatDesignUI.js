import React from 'react'
import { Image, StyleSheet, Text, View } from 'react-native'
import { color } from 'styled-system'
import firebase from './FireScript'

const avatar = require('../publics/images/userProfilIcon.png')

const ChatDesignUI = ({item}) => {
    if(firebase.auth().currentUser) {
        if (firebase.auth().currentUser.email===item.email) {
            return <View style={styles.containerCurrent}>
                <View style={styles.layoutCurrent}>
                    <View style={styles.textLayout}>
                        <Text style={styles.name}>Moi:</Text>
                        <Text>{item.text}</Text>
                    </View>
                </View>
            </View>
        } else {
            return <View style={styles.container}>    
                <View style={styles.layout}>
                    <Image style={styles.avatar} source={avatar} />
                    <View style={styles.textLayout}>
                        <Text style={styles.name}>{item.name}</Text>
                        <Text>{item.text}</Text>
                    </View>
                </View>
            </View>    
        }
    }
    

}

export default ChatDesignUI

const styles = StyleSheet.create({
    container: {
        alignItems: "flex-start",
        flex: 1,
        height: "100%",
        width: "100%",
    },
    containerCurrent: {
        alignItems: "flex-end",
        flex: 1,
        height: "100%",
        width: "100%",
    },
    layout: {
        flexDirection: 'row',
        margin: 8,
        backgroundColor: "#96bf0f",
        padding: 8,
        borderRadius: 3,
    },
    layoutCurrent: {
        flexDirection: 'row',
        margin: 8,
        backgroundColor: "#cecece",
        paddingVertical: 8,
        paddingLeft: 8,
        paddingRight: 12,
        borderRadius: 3,
        alignItems: 'flex-start',
    },
    avatar: {
        width: 40,
        height: 40,
        borderRadius: 50,
    },
    textLayout: {
        padding: 8,
    },
    name: {
        fontSize: 16, 
        fontWeight: '600',
        color: "#FFFFFF"
    }
})
