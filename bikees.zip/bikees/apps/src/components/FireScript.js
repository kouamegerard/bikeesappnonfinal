import * as firebase from 'firebase'

// const firebaseConfig = {
//     apiKey: "AIzaSyAX8WJgl0fn7KKJsn9Tt_-jVr_iFh5PKtM",
//     authDomain: "finalbikeesapp.firebaseapp.com",
//     projectId: "finalbikeesapp",
//     storageBucket: "finalbikeesapp.appspot.com",
//     messagingSenderId: "877607907749",
//     appId: "1:877607907749:web:675934f2ce48e976c6784c"
// };
// // Initialize Firebase
// // firebase.initializeApp(firebaseConfig);
// if (!firebase.apps.length) {
//     firebase.initializeApp(firebaseConfig);
// }

const firebaseConfig = {
    apiKey: "AIzaSyCkiFlGbggU9IO1-LDTUK5jSvZoB5_cW0I",
    authDomain: "finalbikeesapps.firebaseapp.com",
    projectId: "finalbikeesapps",
    storageBucket: "finalbikeesapps.appspot.com",
    messagingSenderId: "1083378637570",
    appId: "1:1083378637570:web:0e727ea7a3f104c6be801b"
};
  // Initialize Firebase
  //firebase.initializeApp(firebaseConfig);
  if (!firebase.apps.length) {
    firebase.initializeApp(firebaseConfig);
  }

export default firebase

