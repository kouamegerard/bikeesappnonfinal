import React from 'react'
import { StyleSheet, Text } from 'react-native';

import { Card, CardContainer, Header, BadgeIconSuccess, ImageCard, PricesView, Content, TitleProduct, Footer, BadgeIconError, PriceHourDayText, LinkContainer } from '../publics/bundles/utils/styles';

export const ListProductComponent = ({ item }) => {
    
    return (
        <Card>
            <CardContainer>
                <BadgeIconSuccess>{item.status}</BadgeIconSuccess>
                <Header>
                    <ImageCard source={item.image} resizeMode='center'/>
                </Header>
                <Content>
                    <TitleProduct>{item.title}</TitleProduct>
                    <PricesView>
                        <PriceHourDayText>Prix Heure: {item.priceHour}€</PriceHourDayText>
                        <PriceHourDayText>Prix Jour: {item.priceDay}€</PriceHourDayText>
                    </PricesView>
                </Content>
                <Footer></Footer>
            </CardContainer>
        </Card>
    )
}

const styles = StyleSheet.create({
    container: {
        marginVertical: 8,
        marginEnd: 8,
        marginStart: 8,
        backgroundColor:'#fff',
    },
    imageBox: {
    },
    textBox: {
        flex: .3,
    },
    textTitle: {
        fontWeight: '800',
        fontSize: 28,
        marginBottom: 16,
        color: 'green',
        textAlign: 'center',
    },
    textDescription: {
        fontWeight: '300',
        color: 'green',
        textAlign: 'center',
        paddingHorizontal: 64,
    }
})
