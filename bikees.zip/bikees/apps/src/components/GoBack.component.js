import React from 'react'
import { Alert, Image, StyleSheet, Text, TouchableOpacity, View } from 'react-native'

const goBack = require('../publics/images/goBack.png')

const GoBackComponent = ({navigation}) => {

    const backAction = () => {
        Alert.alert("Patientez!", "Êtes-vous sûr de vouloir y retourner ?", [
          {
            text: "Non",
            onPress: () => null,
            style: "cancel"
          },
          { text: "OUI", onPress: () => navigation.goBack() }
        ]);
        return true;
    };

    return (
        
        <TouchableOpacity
            onPress={backAction}
            opacity='.3' style={styles.goInnerBack}>
            <Image style={styles.goBack} source={goBack}  />
        </TouchableOpacity>
        
    )
}

export default GoBackComponent

const styles = StyleSheet.create({
    goInnerBack: {
        alignItems: 'center',
        position: 'absolute',
        width: 40,
        height: 40,
        top: '3%',
        left: '3%',
    },
    goBack: {
        alignItems: 'center',
        position: 'absolute',
        width: 40,
        height: 40,
        top: '3%',
        left: '3%',
        backgroundColor: 'rgba(255,255,255, .1)',
        marginHorizontal: 3,
        padding: 10,
        borderRadius: 50,
        shadowOffset: { width: 8, height: 10 },
        shadowColor: 'rgba(255,255,255, .4)',
        shadowRadius: 13.16,
        shadowOpacity: 1,
    },
})
