import React, {useState, useEffect} from 'react';
import {View, Text, StatusBar, SafeAreaView, StyleSheet} from 'react-native';
import { useSafeArea } from 'react-native-safe-area-context';


const TOP_SAFE_AREA = 50;
const BANNER_SIZE_H = 350; 

const TopNavigation = (props) => {
  const safeArea = useSafeArea();

  const {title, scrollA} = props;
  const isFloating = !!scrollA;
  const [isTransparent, setTransparent] = useState(isFloating);
  useEffect(() => {
    if (!scrollA) {
      return;
    }
    const listenerId = scrollA.addListener(a => {
      const topNaviOffset = BANNER_SIZE_H - TOP_SAFE_AREA - safeArea.top;
      isTransparent !== a.value < topNaviOffset &&
        setTransparent(!isTransparent);
    });
    return () => scrollA.removeListener(listenerId);
  });

  return (
    <View>
      <StatusBar
        backgroundColor="transparent"
        translucent
        hidden={true}
      />
      <SafeAreaView style={styles.container(safeArea, isFloating, isTransparent)}>
        <Text style={styles.title(isTransparent)}>{title}</Text>
      </SafeAreaView>
    </View>
  );
};

const styles = StyleSheet.create({
  container: (safeArea, isFloating, isTransparent) => ({
    paddingTop: safeArea.top,
    marginBottom: isFloating ? -TOP_SAFE_AREA - safeArea.top : 0,
    height: TOP_SAFE_AREA + safeArea.top,
    justifyContent: 'center',
    shadowOffset: {y: 0},
    backgroundColor: isTransparent ? 'rgba(255,255,255, .7)' : '#FFF',
    shadowOpacity: isTransparent ? 0 : 0.1,
    elevation: isTransparent ? 0.01 : 5,
    zIndex: 9999,
  }),
  title: isTransparent => ({
    textAlign: 'center',
    fontWeight: 'bold',
    fontSize: 16,
    color: isTransparent ? '#FFF' : '#000',
  }),
});

export default TopNavigation;