import {createStackNavigator} from 'react-navigation-stack';
import {createAppContainer} from 'react-navigation';
import LoginSignScreen from '../publics/screens/signs/LoginSignScreen';
import RegisterSignScreen from '../publics/screens/signs/RegisterSignScreen';

const stackNavigatorOptions = {
    headerShown:false
}
const AppNavigator = createStackNavigator(
    {
        LoginSignScreen:{screen:LoginSignScreen},
        RegisterSignScreen:{screen:RegisterSignScreen},
    },
    {
        defaultNavigationOptions : stackNavigatorOptions
    }  
);
export default createAppContainer(AppNavigator);