import React from 'react'
import { Alert, StyleSheet, Text, View } from 'react-native'

export const SkipToNext = ({ navigation }) => {
    return (
        <View style={styles.container}>
            <Text 
                style={styles.skipText}
                onPress={() => Alert.alert('Click me')}
            >Skip</Text>
        </View>
    )
}

const styles = StyleSheet.create({
    container: {
        flex: .1,
        alignItems: 'flex-end',
        justifyContent: 'center',
        marginHorizontal: 16,
    },
    skipText: {
        color: '#f00',
    }
})
