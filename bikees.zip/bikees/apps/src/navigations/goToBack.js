import React, {useEffect, useState} from 'react'
import { Alert, StyleSheet, Text, View } from 'react-native'

export const goToBack = ({navigation}) => {
    
    Alert.alert("Patientez!", "Êtes-vous sûr de vouloir y retourner ?", [
        {
          text: "Non",
          onPress: () => null,
          style: "cancel"
        },
        { text: "OUI", onPress: () => navigation.goBack() }
      ]);
      return true;

}

export default goToBack

