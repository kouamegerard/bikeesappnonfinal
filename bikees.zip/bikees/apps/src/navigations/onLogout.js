const onLogout = () => {
    firebase.auth()
        .signOut()
        .then(() => navigation.navigate('Login'))
};

export default onLogout;