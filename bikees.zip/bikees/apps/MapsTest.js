import React, { useState, useEffect} from "react"
import { Dimensions, StyleSheet, Text, View, AppState, Linking } from "react-native"
import { GooglePlacesAutocomplete } from "react-native-google-places-autocomplete"
import MapView, { Callout, Circle, Marker } from "react-native-maps"
import {Constants} from "expo"
import * as Location from 'expo-location';
import { Permissions } from "expo-permissions";


export const MapsTest = () => {
	const [ pin, setPin ] = React.useState({
		latitude: 37.78825,
		longitude: -122.4324,
	})
	const [ region, setRegion ] = React.useState({
		latitude: 37.78825,
		longitude: -122.4324,
		latitudeDelta: 0.0922,
		longitudeDelta: 0.0421
	})

    const [state, setState] = useState({
        location: null,
        errorLocationMsg: null,
        appState: AppState.currentState,
        isLocationModalVisible: false
    })

    const getLocationAsync = async () => {
        try {
            let { status } = await Permissions.askAsync(Permissions.LOCATION)
            if(status !== 'granted'){
                setState({errorLocationMsg: "Permission refusée"})
                return;
            }

            let locations = await Location.getCurrentPositionAsync({})
            setState({locations})
        } catch (error) {
            let status = Location.getProviderStatusAsync();
            if (!status.locationServicesEnabled) {
                setState({isLocationModalVisible: true})
            }
        }
    }

    const [open, setOpen] = useState({
        latitude: null,
        longitude: null
    })

    const findCurrentLocation = () => {
        navigator.geolocation.getCurrentPosition(
            position => {
                const latitude = JSON.stringify(position.coords.latitude)
                const longitude = JSON.stringify(position.coords.longitude)
                setOpen({latitude, longitude})
            },
            {enableHighAccuracy: true, timeout: 10000, maximumAge: 1000}
        )
    }

    const handleAppStateChange = nextAppState => {
        if (
          state.appState.match(/inactive|background/) &&
          nextAppState === 'active'
        ) {
          console.log('App has come to the foreground!');
          getLocationAsync();
        }
        setState({ appState: nextAppState });
    };

    useEffect(() => {
        AppState.addEventListener('change', handleAppStateChange);
        if (Platform.OS === 'android' && !Constants.isDevice) {
        setState({
            errorMessage:
            'Oops, this will not work on Sketch in an Android emulator. Try it on your device!'
        });
        } else {
        getLocationAsync();
        }
    },[])

    useEffect(() => {
        AppState.removeEventListener('change', handleAppStateChange);
        console.log(findCurrentLocation())
    })

    useEffect(() => {
        let text = 'Waiting..';
        console.log("Start location: ", text);
        if (state.errorMessage) {
            text = state.errorMessage;
            console.log("Fund Error location: ", text);
        } else if (state.location) {
            text = JSON.stringify(state.location);
            console.log("Fund true location: ", text);
        }
    }, [state.location])


	return (
		<View style={{ marginTop: 50, flex: 1 }}>
            
			<GooglePlacesAutocomplete
				placeholder="Search"
				fetchDetails={true}
				GooglePlacesSearchQuery={{
					rankby: "distance"
				}}
				onPress={(data, details = null) => {
					// 'details' is provided when fetchDetails = true
					console.log(data, details)
					setRegion({
						latitude: details.geometry.location.lat,
						longitude: details.geometry.location.lng,
						latitudeDelta: 0.0922,
						longitudeDelta: 0.0421
					})
				}}
				query={{
					key: "AIzaSyCf65ToLo88bl3wmPjoRzzYhAeeWxycrlw",
					language: "fr",
					components: "country:us",
					types: "address",
					radius: 30000,
					location: `${region.latitude}, ${region.longitude}`
				}}
				styles={{
					container: { flex: 0, position: "absolute", width: "100%", zIndex: 1 },
					listView: { backgroundColor: "white" }
				}}
			/>
			<MapView
				style={styles.map}
				initialRegion={{
					latitude: 37.78825,
					longitude: -122.4324,
					latitudeDelta: 0.0922,
					longitudeDelta: 0.0421
				}}
				provider="google"
			>
				<Marker coordinate={{ latitude: region.latitude, longitude: region.longitude }} />
				<Marker
					coordinate={pin}
					pinColor="black"
					draggable={true}
					onDragStart={(e) => {
						console.log("Drag start", e.nativeEvent.coordinates)
					}}
					onDragEnd={(e) => {
						setPin({
							latitude: e.nativeEvent.coordinate.latitude,
							longitude: e.nativeEvent.coordinate.longitude
						})
					}}
				>
					<Callout>
						<Text>I'm here</Text>
					</Callout>
				</Marker>
				<Circle center={pin} radius={1000} />
			</MapView>
		</View>
	)
}

const styles = StyleSheet.create({
	container: {
		flex: 1,
		backgroundColor: "#fff",
		alignItems: "center",
		justifyContent: "center"
	},
	map: {
		width: Dimensions.get("window").width,
		height: Dimensions.get("window").height
	}
})